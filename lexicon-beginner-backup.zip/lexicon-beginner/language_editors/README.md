# alexa-skill-vocabulary
* Conrtibutors: @CharalamposTheodorou
* Tags: alexa, skill, amazon, alexa skit
* Current version: 1.0

## Description:
This directory contains all the JSON editor files for all available languaes. These are the dialog and keyword options configured in the alexa developer console in the "Build" tab.


