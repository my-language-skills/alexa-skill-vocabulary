# alexa-skill-vocabulary
* Conrtibutors: @CharalamposTheodorou
* Tags: alexa, skill, amazon, alexa skit
* Current version: 1.0

## Description:
This directory contains all the content files needed for the skill to operate.
-

## Content
- All the information of the current level of learning
- In all available languages.
  - It is required true/false to activate or not a word.
  - If one word is missing....
  - If one example is missing...
  - If one category is missing...
- The codes of the words are just for organization purposes. The only code is the one of the categories.



## Editor_options
- All the keywords of the JSON editors in all available languages.
- This is used to check if the keyword spoken by the user was given in one of two selected languages (learning and native).
- If any more keywords are added to any future release this file should be updated as well.


## language_strings
- All the response messages given from alexa in all available languages.
